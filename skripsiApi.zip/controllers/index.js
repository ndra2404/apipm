
const authController = require('./auth.controller')
const topController = require('./topup.controller')
const pMController = require('./profilematching.controller')
const KreteriaController = require('./kreteria.controller')
const userController = require('./user.controller')
const pelamarController = require('./pelamar.controller')

module.exports = {
  authController,
  topController,
  pMController,
  KreteriaController,
  userController,
  pelamarController
}
